# cubelyr 1.0.1

usethis::use_version('patch')# cubelyr (development version)

* Fixes for dplyr compatibility

# cubelyr 1.0.0

* Added a `NEWS.md` file to track changes to the package.
