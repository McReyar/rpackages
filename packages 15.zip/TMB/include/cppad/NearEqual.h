/* $Id$ */
# include "cppad/near_equal.hpp"
