# C50 0.1.3

* Fixed CRAN issues for GCC 10 `-fno-common` flag.

* Added a `NEWS.md` file to track changes to the package.

* Removed `churn` data in favor of the version in the `modeldata` package. 
