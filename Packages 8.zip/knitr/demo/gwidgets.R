# for installation, see https://github.com/jverzani/gWidgetsWWW2
library(gWidgetsWWW2)
options(device.ask.default = FALSE)
load_app(system.file('misc', 'gWidgetsWWW2-knitr.R', package = 'knitr'))
