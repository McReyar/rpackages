# Simulate Friedman benchmark data
trn1 <- gen_friedman(100, seed = 1421)
trn2 <- gen_friedman(100, seed = 1421, n_bins = 2)

# Fit a random forest
set.seed(1502)  # for reproducibility
fit1 <- lm(y ~ ., data = trn1)
fit2 <- glm(y ~ ., data = trn2, family = binomial(link = "logit"))

# Prediction wrapper
pfun <- function(object, newdata) {
  predict(object, newdata = newdata, type = "response")
}

# Compute SHAP-based VI scores
set.seed(1511)  # for reproducibiliity
vis1 <- vi_shap(fit1, pred_wrapper = pfun, nsim = 10)
vis2 <- vi_shap(fit2, pred_wrapper = pfun, nsim = 10)
vis3 <- vi(fit1, method = "shap", pred_wrapper = pfun, nsim = 10,
           .progress = "text")

# Try using vip directly
p <- vip(fit1, method = "shap", pred_wrapper = pfun, nsim = 10,
         .progress = "text")

# Display plots in a grid
grid.arrange(vip(vis1), vip(vis2), vip(vis3), p, nrow = 2)
