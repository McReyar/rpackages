library("scales")

show_col(fivethirtyeight_pal()(3))
