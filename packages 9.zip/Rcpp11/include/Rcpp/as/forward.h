#ifndef Rcpp__as__forward_h
#define Rcpp__as__forward_h

namespace Rcpp{
    template <typename T> T as( SEXP m_sexp) ;
} // Rcpp 

#endif
