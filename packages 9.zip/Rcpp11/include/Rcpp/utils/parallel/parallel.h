#ifndef RCPP11_TOOLS_PARALLEL_PARALLEL_H
#define RCPP11_TOOLS_PARALLEL_PARALLEL_H

#include <Rcpp/utils/parallel/copy.h>
#include <Rcpp/utils/parallel/transform.h>
#include <Rcpp/utils/parallel/iota.h>
#include <Rcpp/utils/parallel/generate_n.h>
      
#endif                      
