#ifndef Rcpp11_storage_storage_h
#define Rcpp11_storage_storage_h

#include <Rcpp/storage/PreserveStorage.h>
#include <Rcpp/storage/NoProtectStorage.h>

#endif
