#ifndef Rcpp__sugar__functional__functional_h
#define Rcpp__sugar__functional__functional_h

#include <Rcpp/sugar/functional/Functoid.h>
#include <Rcpp/sugar/functional/compose.h>
#include <Rcpp/sugar/functional/negate.h>

#endif 
