#ifndef Rcpp_Evaluator_h
#define Rcpp_Evaluator_h

#define R_NO_REMAP
#include <Rinternals.h>

#endif
