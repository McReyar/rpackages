#ifndef Rcpp__protection_h
#define Rcpp__protection_h

#include <Rcpp/protection/Shield.h>
#include <Rcpp/protection/Armor.h>

#endif
