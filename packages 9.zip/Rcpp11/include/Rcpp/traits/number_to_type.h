#ifndef Rcpp__traits__number_to_type__h
#define Rcpp__traits__number_to_type__h

namespace Rcpp{
    namespace traits{
        template <unsigned int N> struct number_to_type {};
    }
}
#endif
