#ifndef Rcpp_registration_registration_h
#define Rcpp_registration_registration_h

#include <Rcpp/registration/DotCall.h>
#include <Rcpp/registration/DotExternal.h>

#endif
