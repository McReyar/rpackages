library("scales")

show_col(gdocs_pal()(20))
